module.exports = [
  ['PEPP', 'Pepperoni', 12793, 15, 65],
  ['MEAT', 'Meat Lovers', 7588, 20, 35],
  ['HAWA', 'Hawaiian', 1214, 13, 50],
  ['SUPR', 'Supreme', 2214]
];
